package com.lagou.mr.wc;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class SortReducer extends Reducer<LongWritable,LongWritable,LongWritable,LongWritable> {

    private static LongWritable linesum = new LongWritable(1);

    @Override
    protected void reduce(LongWritable key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
        for (LongWritable v : values) {
            context.write(linesum, key);
            linesum = new LongWritable(linesum.get() + 1);
        }
    }
}